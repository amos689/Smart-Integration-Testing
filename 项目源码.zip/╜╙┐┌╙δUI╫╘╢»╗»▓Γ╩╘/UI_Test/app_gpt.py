from config.setup import setup_driver
from test_unit_gpt.eg0_login import login
from test_unit_gpt.eg1_read_user_detail import read_user_detail
from test_unit_gpt.eg2_alter_b_available import alter_b_available
from test_unit_gpt.eg3_add_administrator import add_administrator
from test_unit_gpt.eg4_adjust_activity import adjust_activity


def main():
    driver_path = "driver/chromedriver.exe"
    driver = setup_driver(driver_path)

    try:
        # 登录
        login(driver, "http://117.50.195.127:8080", "ratest", "")

        # 测试用例 1
        read_user_detail(driver)

        # 测试用例 2
        alter_b_available(driver)

        # 测试用例 3（注意昵称和用户名不要重名！）
        add_administrator(driver, "ra_auto_4", "ra_auto_4", "")

        # 测试用例 4
        adjust_activity(driver, 6, 114514, 19, 19, 810)

    finally:
        driver.quit()


if __name__ == "__main__":
    main()
