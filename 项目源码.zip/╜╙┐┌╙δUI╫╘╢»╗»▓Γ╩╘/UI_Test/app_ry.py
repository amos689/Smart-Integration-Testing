from config.setup import setup_driver
from test_unit_ry.eg0_login import login
from test_unit_ry.eg_5_system_info import read_system_info
from test_unit_ry.eg_6_user_add import user_add
from test_unit_ry.eg_7_user_delete import user_delete
from test_unit_ry.eg_8_alter_admin import alter_admin


def main():
    driver_path = "driver/chromedriver.exe"
    driver = setup_driver(driver_path)

    try:
        # 登录
        login(driver, "http://117.50.195.127:6343", "admin", "")

        # 测试用例 1
        read_system_info(driver)
        # 测试用例 2
        user_add(driver, "aaabbb", "bbbaaa", "cccdddeee")
        # 测试用例 3
        user_delete(driver, "aaabbb")
        # 测试用例 4
        alter_admin(driver, "RuoYiAdmin", "13688887777", "114514@1919810.com")

    finally:
        driver.quit()


if __name__ == "__main__":
    main()
