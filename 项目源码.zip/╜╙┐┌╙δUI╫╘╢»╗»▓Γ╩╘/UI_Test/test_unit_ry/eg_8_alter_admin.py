from time import sleep
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


def get_admin_info(driver):
    # 定位所有的 list-group-item
    list_group_items = driver.find_elements(By.CSS_SELECTOR, "ul.list-group.list-group-striped li.list-group-item")

    for item in list_group_items:
        # 获取 <b> 标签内容
        b_element = item.find_element(By.TAG_NAME, "b")
        b_text = b_element.text

        # 获取 <p> 标签内容
        p_element = item.find_element(By.TAG_NAME, "p")
        p_text = p_element.text

        # 输出内容到控制台
        print(f"{b_text} {p_text}")


def alter_admin(driver, username, phone, email):
    try:
        # 定位并点击包含指定<img>标签的<div>元素
        div_element = driver.find_element(By.CSS_SELECTOR, "div.pull-left.image")
        div_element.click()
        sleep(3)
    except Exception as e:
        print(f"发生错误: {e}")

    try:
        print("=================== 测试用例 8：修改管理员信息 ===================\n")
        driver.switch_to.frame(driver.find_element(By.XPATH, "//iframe[@data-id='/system/user/profile']"))

        print("修改前信息")
        get_admin_info(driver)

        username_input = driver.find_element(By.NAME, "userName")
        phone_input = driver.find_element(By.NAME, "phonenumber")
        email_input = driver.find_element(By.NAME, "email")

        username_input.clear()
        phone_input.clear()
        email_input.clear()

        username_input.send_keys(username)
        phone_input.send_keys(phone)
        email_input.send_keys(email)

        save_button = driver.find_element(By.XPATH, "//button[contains(text(), '保 存')]")
        save_button.click()

        # 等待页面加载并定位“确定”按钮
        driver.switch_to.default_content()
        confirm_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, ".layui-layer-btn0"))
        )
        # 点击“确认”按钮
        confirm_button.click()
        sleep(3)

        # 定位并点击包含指定文字的<a>标签
        refresh_link = driver.find_element(By.CSS_SELECTOR, "a.roll-nav.roll-right.tabReload")
        refresh_link.click()
        sleep(2)

        driver.switch_to.frame(driver.find_element(By.XPATH, "//iframe[@data-id='/system/user/profile']"))
        print("\n修改后信息")
        get_admin_info(driver)

        driver.switch_to.default_content()
        sleep(2)
        print("\n=================== 测试用例 8 结束 ===================\n")

    except Exception as e:
        print(f"发生错误: {e}")
