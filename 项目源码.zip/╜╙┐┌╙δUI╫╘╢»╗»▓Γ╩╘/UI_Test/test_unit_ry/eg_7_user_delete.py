from time import sleep
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


def user_delete(driver, username):
    try:
        print("=================== 测试用例 7：删除用户 ===================\n")
        # 切换到用户管理 iFrame
        driver.switch_to.frame(driver.find_element(By.XPATH, "//iframe[@name='iframe2']"))

        # 找到包含用户名 'aaabbb' 的行
        row = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, f"//tr[td[contains(text(), {username})]]"))
        )

        # 在该行中找到删除按钮并点击
        delete_button = row.find_element(By.XPATH, ".//a[contains(@class, 'btn-danger') and contains(., '删除')]")
        delete_button.click()

        # 等待页面加载并定位“确定”按钮
        driver.switch_to.default_content()
        confirm_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, ".layui-layer-btn0"))
        )
        # 点击“确认”按钮
        confirm_button.click()
        sleep(3)

        try:
            # 使用显式等待查找包含特定文本的元素
            driver.switch_to.frame(driver.find_element(By.XPATH, "//iframe[@name='iframe2']"))
            element = WebDriverWait(driver, 3).until(
                EC.presence_of_element_located((By.XPATH, f"//tr[td[text()={username}]]"))
            )
        except Exception as e:
            print("用户已经删除！")

        driver.switch_to.default_content()
        print("\n=================== 测试用例 7 结束 ===================\n")
        sleep(2)
    except Exception as e:
        print(f"发生错误: {e}")
