from time import sleep
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


def read_system_info(driver):
    try:
        # 等待页面加载并定位“系统工具”菜单项
        system_monitor_menu = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//span[text()='系统监控']"))
        )
        # 点击“系统监控”菜单项以展开子菜单
        system_monitor_menu.click()
        sleep(1)
    except Exception as e:
        print(f"发生错误: {e}")

    try:
        # 等待并点击“服务监控”子菜单项
        service_monitoring_menu = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//a[text()='服务监控']"))
        )
        service_monitoring_menu.click()
        sleep(5)
    except Exception as e:
        print(f"发生错误: {e}")

    try:
        driver.switch_to.frame(driver.find_element(By.XPATH, "//iframe[@name='iframe15']"))
        data = {}
        rows = driver.find_elements(By.XPATH, "//tbody/tr")
        # print(rows)
        print("=================== 测试用例 5：读取系统监控信息 ===================\n")

        for row in rows:
            cells = row.find_elements(By.XPATH, "//tbody/tr/td")
            contents = []
            key = "系统监控"
            for i in range(0, len(cells)):
                contents.append(cells[i].text.strip())
                data[key] = contents

        # 打印结果
        import json
        print(json.dumps(data, indent=4, ensure_ascii=False))
        print("\n=================== 测试用例 5 结束 ===================\n")

        sleep(1)
        driver.switch_to.default_content()
        sleep(2)
    except Exception as e:
        print(f"发生错误: {e}")
