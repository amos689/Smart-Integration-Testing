from time import sleep
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


def user_add(driver, username, loginname, password):
    try:
        # 等待页面加载并定位“系统管理”菜单项
        system_monitor_menu = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//span[text()='系统管理']"))
        )
        # 点击“系统监控”菜单项以展开子菜单
        system_monitor_menu.click()
        sleep(1)
    except Exception as e:
        print(f"发生错误: {e}")

    try:
        # 等待并点击“用户管理”子菜单项
        service_monitoring_menu = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//a[text()='用户管理']"))
        )
        service_monitoring_menu.click()
        sleep(2)
    except Exception as e:
        print(f"发生错误: {e}")

    try:
        print("=================== 测试用例 6：新建用户 ===================\n")
        # 切换到用户管理 iFrame
        driver.switch_to.frame(driver.find_element(By.XPATH, "//iframe[@name='iframe2']"))

        # 等待并点击“新增”按钮
        add_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//a[contains(@class, 'btn-success') and contains(., '新增')]"))
        )
        # 点击“新增”按钮
        add_button.click()
        sleep(2)

        # 切换到用户添加 iFrame
        driver.switch_to.default_content()
        driver.switch_to.frame(driver.find_element(By.XPATH, "//iframe[@data-id='/system/user/add']"))

        # 找到用户名、密码输入框和登录按钮
        username_input = driver.find_element(By.NAME, "userName")
        loginname_input = driver.find_element(By.NAME, "loginName")
        password_input = driver.find_element(By.NAME, "password")

        username_input.clear()
        loginname_input.clear()
        password_input.clear()

        username_input.send_keys(username)
        loginname_input.send_keys(loginname)
        password_input.send_keys(password)

        save_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//button[@type='button' and contains(@class, 'btn-primary') and contains(., '保 存')]"))
        )
        save_button.click()

        sleep(1)
        driver.switch_to.default_content()
        driver.switch_to.frame(driver.find_element(By.XPATH, "//iframe[@name='iframe2']"))
        try:
            # 使用显式等待查找包含特定文本的元素
            element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, f"//*[contains(text(), {username})]"))
            )
            print(f"用户已添加！")
        except Exception as e:
            print("用户未正常添加", e)

        driver.switch_to.default_content()
        print("\n=================== 测试用例 6 结束 ===================\n")
        sleep(2)
    except Exception as e:
        print(f"发生错误: {e}")
