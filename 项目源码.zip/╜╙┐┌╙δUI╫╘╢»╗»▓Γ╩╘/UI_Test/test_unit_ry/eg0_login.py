from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
import time


def login(driver, url, username_str, password_str):
    try:
        # 打开网页
        driver.get(url)
        time.sleep(3)

        # 找到用户名、密码输入框和登录按钮
        username = driver.find_element(By.NAME, "username")
        password = driver.find_element(By.NAME, "password")

        # 输入用户名和密码
        username.clear()
        password.clear()
        username.send_keys(username_str)
        password.send_keys(password_str)

        # 等待页面加载并定位按钮
        submit_button = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "btnSubmit"))
        )

        # 点击按钮
        submit_button.click()

        # 等待页面加载
        print("已执行登录")

        # 关闭弹窗
        try:
            # 等待页面加载并定位“取消”按钮
            cancel_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, ".layui-layer-btn1"))
            )
            # 点击“取消”按钮
            cancel_button.click()
            time.sleep(1)
        except Exception as e:
            print(f"发生错误: {e}")
    except Exception as e:
        print(f"发生错误: {e}")
