import time

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


def alter_b_available(driver):
    try:
        print("=================== 测试用例 2：更改用户套餐可用性 ===================\n")
        # 定位并点击“废除”按钮
        abolish_button = driver.find_element(By.XPATH, "//button[@class='el-button el-button--danger el-button--mini is-plain']")
        abolish_button.click()

        # 等待并点击确认框中的确定按钮
        confirm_button = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//div[@role='dialog']//button[@class='el-button el-button--default el-button--small el-button--primary ']"))
        )
        confirm_button.click()
        success_message = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located(
                (By.CSS_SELECTOR, "div.el-message.el-message--success p.el-message__content"))
        )
        print("执行禁用操作，捕获到弹窗:", success_message.text)
        time.sleep(2)

    except Exception as e:
        print(f"操作过程中出现错误: {e}")

    try:
        restore_button = driver.find_element(By.XPATH, "//button[contains(@class, 'el-button--primary') and contains(@class, 'el-button--mini') and contains(@class, 'is-plain')]//span[normalize-space(text())='恢复']")
        restore_button.click()

        # 等待并点击确认框中的确定按钮
        confirm_button = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//div[@role='dialog']//button[@class='el-button el-button--default el-button--small el-button--primary ']"))
        )
        confirm_button.click()
        success_message = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located(
                (By.CSS_SELECTOR, "div.el-message.el-message--success p.el-message__content"))
        )
        print("执行恢复操作，捕获到弹窗:", success_message.text)

        time.sleep(1)
        try:
            # 定位并点击包含“详情”字样的关闭按钮
            close_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(@aria-label, '详情')]"))
            )
            close_button.click()
        except Exception as e:
            print(f"操作过程中出现错误: {e}")
        print("\n=================== 测试用例 2 结束 ===================\n")
        time.sleep(2)
    except Exception as e:
        print(f"操作过程中出现错误: {e}")
