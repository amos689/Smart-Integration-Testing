from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
import time


def login(driver, url, username_str, password_str):
    try:
        # 打开网页
        driver.get(url)
        time.sleep(3)

        # 找到用户名、密码输入框和登录按钮
        username = driver.find_element(By.NAME, "username")
        password = driver.find_element(By.NAME, "password")
        login_button = driver.find_element(By.XPATH, '//button[@type="button" and contains(@class, "el-button--primary") and contains(@class, "el-button--mini")]')

        # 输入用户名和密码
        username.clear()
        password.clear()
        username.send_keys(username_str)
        password.send_keys(password_str)

        # 点击登录按钮
        login_button.click()

        # 等待页面加载
        print("已执行登录")

        # 关闭弹窗
        try:
            # 等待弹窗出现
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "div.el-message-box__wrapper")))
            # 点击确定按钮
            confirm_button = driver.find_element(By.CSS_SELECTOR, "div.el-message-box__btns button.el-button--primary")
            confirm_button.click()
            time.sleep(1)
        except Exception as e:
            print(f"发生错误: {e}")
    except Exception as e:
        print(f"发生错误: {e}")
