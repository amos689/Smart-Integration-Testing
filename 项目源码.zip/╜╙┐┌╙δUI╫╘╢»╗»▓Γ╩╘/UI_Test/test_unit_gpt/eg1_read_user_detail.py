from time import sleep

from selenium.common import NoSuchElementException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


# 点击会员列表
def click_member_list(driver):
    # 检查菜单是否为active状态
    try:
        hamburger_menu = driver.find_element(By.CSS_SELECTOR, "svg.hamburger")
        if "is-active" not in hamburger_menu.get_attribute("class"):
            hamburger_menu.click()
            # print("发现菜单未展开，已展开")
            sleep(3)  # 等待侧栏展开
    except NoSuchElementException:
        print("菜单未找到")

    try:
        # 等待页面出现
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "li.el-menu-item")))
        # 查找包含"会员列表"文本的菜单项
        member_list_item = driver.find_element(By.XPATH, "//li[contains(@class, 'el-menu-item') and .//span[text()='会员列表']]")
        member_list_item.click()
        # print("会员列表菜单项已点击")
        # Sleep 一会儿
        sleep(3)
    except Exception as e:
        print(f"发生错误: {e}")


# 点击指定用户的编辑按钮并读取用户信息
def edit_user_test(driver):
    try:
        # 定位到包含“2”的<td>元素，并找到它的父<tr>元素
        target_tr = driver.find_element(By.XPATH, "//div[contains(@class, 'cell el-tooltip') and normalize-space(text())='2']/ancestor::tr")
        # 在该<tr>元素内查找包含“编辑”文本的按钮
        edit_button = target_tr.find_element(By.XPATH, ".//button[.//span[text()='编辑']]")
        edit_button.click()
        # print("编辑按钮已点击")
        try:
            # 定位用户名（账号）输入框
            username_input = driver.find_element(By.XPATH, "//label[text()='用户名（账号）']/following-sibling::div//input[@type='text']")
            username_value = username_input.get_attribute('value')
            print("=================== 测试用例 1：读取用户套餐信息 ===================\n")
            print(f"用户名（账号）：{username_value}")
            # 定位昵称输入框
            nickname_input = driver.find_element(By.XPATH, "//label[text()='昵称']/following-sibling::div//input[@type='text']")
            nickname_value = nickname_input.get_attribute('value')
            print(f"昵称：{nickname_value}")
        except Exception as e:
            print(f"发生错误: {e}")
    except NoSuchElementException:
        print("目标<div>或编辑按钮未找到")
    except Exception as e:
        print(f"发生错误: {e}")


# 测试例一：读取用户套餐信息
def read_user_detail(driver):
    # 前置操作
    click_member_list(driver)
    edit_user_test(driver)

    try:
        # 点击“套餐列表”选项卡
        # package_tab = driver.find_element(By.ID, "tab-balance")
        # package_tab.click()
        # print("套餐列表选项卡已点击")
        sleep(1)  # 等待页面加载
        try:
            # 查找并点击包含 `el-icon el-icon-arrow-right` 的展开按钮
            try:
                expand_icon = driver.find_element(By.CSS_SELECTOR, "div.el-table__expand-icon i.el-icon-arrow-right")
                expand_icon.click()
                # print("展开按钮已点击")
                sleep(1)  # 等待展开内容加载
            except NoSuchElementException:
                print("展开按钮未找到")

            # 等待展开内容加载
            try:
                expanded_cell = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, "td.el-table__expanded-cell"))
                )
                tokens = expanded_cell.find_element(By.XPATH, ".//label[text()='tokens']/following-sibling::div/span").text
                normal_chats = expanded_cell.find_element(By.XPATH, ".//label[text()='普通聊天次数']/following-sibling::div/span").text
                advanced_chats = expanded_cell.find_element(By.XPATH, ".//label[text()='高级聊天次数']/following-sibling::div/span").text
                drawings = expanded_cell.find_element(By.XPATH, ".//label[text()='绘画次数']/following-sibling::div/span").text

                # 打印和返回读取的文本
                print(f"tokens: {tokens}")
                print(f"普通聊天次数: {normal_chats}")
                print(f"高级聊天次数: {advanced_chats}")
                print(f"绘画次数: {drawings}")
                print("\n=================== 测试用例 1 结束 ===================\n")
                sleep(2)
            except TimeoutException:
                print("等待展开内容超时")
            except NoSuchElementException:
                print("未找到展开的内容")
        except Exception as e:
            print(f"发生错误: {e}")
    except Exception as e:
        print(f"发生错误: {e}")
