from time import sleep

from selenium.common import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


def add_administrator(driver, nickname, username, password):
    # 检查菜单是否为active状态
    try:
        hamburger_menu = driver.find_element(By.CSS_SELECTOR, "svg.hamburger")
        if "is-active" not in hamburger_menu.get_attribute("class"):
            hamburger_menu.click()
            # print("发现菜单未展开，已展开")
            sleep(2)  # 等待侧栏展开
    except NoSuchElementException:
        print("菜单未找到")

    try:
        print("=================== 测试用例 3：添加管理员操作 ===================\n")
        # 等待页面出现
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "li.el-menu-item")))
        # 查找包含"管理员列表"文本的菜单项
        member_list_item = driver.find_element(By.XPATH, "//li[contains(@class, 'el-menu-item') and .//span[text()='管理员列表']]")
        member_list_item.click()
        sleep(2)
    except Exception as e:
        print(f"发生错误: {e}")

    try:
        # 定位并点击“新增”按钮
        add_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable(
                (By.XPATH, "//button[@class='el-button el-button--primary el-button--mini']//span[text()='新增']"))
        )
        add_button.click()
    except Exception as e:
        print(f"操作过程中出现错误: {e}")

    try:
        # 等待弹出对话框的出现
        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "//div[@role='dialog' and @aria-label='创建用户']"))
        )

        # 填入昵称
        nickname_input = driver.find_element(By.XPATH, "//label[text()='昵称']/following-sibling::div//input")
        nickname_input.send_keys(nickname)

        # 填入用户名(账号)
        username_input = driver.find_element(By.XPATH, "//label[text()='用户名(账号)']/following-sibling::div//input")
        username_input.send_keys(username)

        # 填入密码
        password_input = driver.find_element(By.XPATH, "//label[text()='密码']/following-sibling::div//input")
        password_input.send_keys(password)

        # 点击提交按钮
        submit_button = driver.find_element(By.XPATH, "//span[text()='提 交']/ancestor::button")
        submit_button.click()

        try:
            success_message = WebDriverWait(driver, 10).until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "div.el-message.el-message--success p.el-message__content"))
            )
            print("执行添加管理员操作，捕获到弹窗:", success_message.text)
            print("\n=================== 测试用例 3 结束 ===================\n")
        except Exception as e:
            print(f"操作过程中出现错误: {e}")
    except Exception as e:
        print(f"操作过程中出现错误: {e}")

    sleep(2)
