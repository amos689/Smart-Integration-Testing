from time import sleep

from selenium.common import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


def adjust_activity(driver, day, tokens, chat_count, ad_chat_count, draw_count):
    # 检查菜单是否为active状态
    try:
        hamburger_menu = driver.find_element(By.CSS_SELECTOR, "svg.hamburger")
        if "is-active" not in hamburger_menu.get_attribute("class"):
            hamburger_menu.click()
            # print("发现菜单未展开，已展开")
            sleep(2)  # 等待侧栏展开
    except NoSuchElementException:
        print("菜单未找到")

    try:
        print("=================== 测试用例 4：修改注册活动 ===================\n")
        # 等待页面出现
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "li.el-menu-item")))
        # 查找包含"活动列表"文本的菜单项
        member_list_item = driver.find_element(By.XPATH, "//li[contains(@class, 'el-menu-item') and .//span[text()='活动列表']]")
        member_list_item.click()
        sleep(2)
    except Exception as e:
        print(f"发生错误: {e}")

    try:
        # 等待“注册赠额”文本和“配置”按钮的出现
        configure_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//div[span[text()='注册赠额']]//button[span[text()='配置']]"))
        )
        configure_button.click()
    except Exception as e:
        print(f"操作过程中出现错误: {e}")

    try:
        # 等待弹出对话框的出现
        dialog = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "//div[@role='dialog' and @aria-label='注册赠额活动配置']"))
        )

        # 修改天数
        days_input = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@role='dialog' and @aria-label='注册赠额活动配置']//label[text()='天数']/following-sibling::div//input"))
        )
        days_input.clear()
        days_input.send_keys(day)

        # 修改 tokens
        tokens_input = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@role='dialog' and @aria-label='注册赠额活动配置']//label[text()='tokens']/following-sibling::div//input"))
        )
        tokens_input.clear()
        tokens_input.send_keys(tokens)

        # 修改普通聊天次数
        normal_chat_input = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@role='dialog' and @aria-label='注册赠额活动配置']//label[text()='普通聊天次数']/following-sibling::div//input"))
        )
        normal_chat_input.clear()
        normal_chat_input.send_keys(chat_count)

        # 修改高级聊天次数
        advanced_chat_input = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@role='dialog' and @aria-label='注册赠额活动配置']//label[text()='高级聊天次数']/following-sibling::div//input"))
        )
        advanced_chat_input.clear()
        advanced_chat_input.send_keys(ad_chat_count)

        # 修改 AI 绘图次数
        ai_drawing_input = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@role='dialog' and @aria-label='注册赠额活动配置']//label[text()='AI绘图次数']/following-sibling::div//input"))
        )
        ai_drawing_input.clear()
        ai_drawing_input.send_keys(draw_count)

        # 点击提交按钮
        submit_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable(
                (By.XPATH, "//div[@role='dialog' and @aria-label='注册赠额活动配置']//button[span[text()=' 提 交 ']]"))
        )
        submit_button.click()

        # 等待提交成功的提示出现
        try:
            success_message = WebDriverWait(driver, 10).until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "div.el-message.el-message--success p.el-message__content"))
            )
            print("已提交修改，捕获到弹窗:", success_message.text)
            print("\n=================== 测试用例 4 结束 ===================\n")
        except Exception as e:
            print(f"操作过程中出现错误: {e}")
    except Exception as e:
        print(f"操作过程中出现错误: {e}")
    sleep(2)
