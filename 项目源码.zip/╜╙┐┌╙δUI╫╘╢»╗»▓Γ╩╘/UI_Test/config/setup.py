from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options


# 定义一个函数 setup_driver，用于设置浏览器驱动
def setup_driver(driver_path):
    # 创建一个Service对象，指定chrome_driver_path
    service = Service(executable_path=driver_path)
    # 创建一个Options对象
    options = Options()
    # 添加excludeSwitches参数，排除enable-automation
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    # 添加useAutomationExtension参数，设置为False
    options.add_experimental_option('useAutomationExtension', False)
    # 添加argument参数，禁用blink-features
    options.add_argument("--disable-blink-features=AutomationControlled")

    # 创建一个Chrome浏览器驱动
    driver = webdriver.Chrome(service=service, options=options)
    # 执行cdp_cmd命令，添加一个ScriptToEvaluateOnNewDocument，设置navigator.webdriver为undefined
    driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    })
    # 返回驱动
    return driver
