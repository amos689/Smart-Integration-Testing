from BeautifulReport import BeautifulReport
import unittest
from Interface_Test.BaoTaTestFTP import TestFTPAPI
from Interface_Test.BaoTaTestMySQL import TestMySQLAPI
from Interface_Test.BaoTaTestSpringBoot import TestSpringBootAPI
from Interface_Test.BaoTaTestUpload import TestUpload
from Interface_Test.SendEmail import EmailSender

def summary_format(result):
    summary = "\n" + u"<p>          测试结果汇总信息                </p>" + "\n" + \
                 u"<p> 开始时间: " + result['beginTime'] + u" </p>" + "\n" + \
                 u"<p> 运行时间: " + result['totalTime'] + u" </p>" + "\n" + \
                 u"<p> 执行用例数: " + str(result['testAll']) + u" </p>" + "\n" + \
                 u"<p> 通过用例数: " + str(result['testPass']) + u" </p>" + "\n" + \
                 u"<p> 失败用例数: " + str(result['testFail']) + u" </p>" + "\n" + \
                 u"<p> 忽略用例数: " + str(result['testSkip']) + u" </p>" + "\n"
    return summary

def suite():
    suite = unittest.TestSuite()
    loader = unittest.TestLoader()
    suite.addTests(loader.loadTestsFromTestCase(TestFTPAPI))
    suite.addTests(loader.loadTestsFromTestCase(TestUpload))
    suite.addTest(loader.loadTestsFromTestCase(TestMySQLAPI))
    suite.addTest(loader.loadTestsFromTestCase(TestSpringBootAPI))
    return suite

if __name__ == '__main__':
    br = BeautifulReport(suite())
    br.report(filename='testdemoreport.html',description='测试报告',report_dir='.')
    rpt_summary = summary_format(br.fields)
    es = EmailSender(rpt_summary)
    es.send_email()