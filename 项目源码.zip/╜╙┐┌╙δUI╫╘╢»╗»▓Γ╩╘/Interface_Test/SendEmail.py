import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import logging


class EmailSender:
    def __init__(self, context=None):
        self.sender = '1297289742@qq.com'
        self.receiver = '1297289742@qq.com'
        self.password = ''
        self.smtp_server = 'smtp.qq.com'
        self.smtp_port = 465
        self.content = context
        logging.basicConfig(filename='email_log.log', level=logging.INFO,
                            format='%(asctime)s - %(levelname)s - %(message)s')

    def send_email(self):
        # 创建邮件对象
        msg = MIMEMultipart()
        msg['From'] = self.sender
        msg['To'] = self.receiver
        msg['Subject'] = '接口自动化测试报表'

        # 添加邮件正文
        msg.attach(MIMEText(self.content, 'html', 'utf-8'))

        # 添加附件
        for attachment in ['./testdemoreport.html']:
            with open(attachment, 'rb') as f:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', 'attachment', filename=attachment)
                msg.attach(part)

        # 连接SMTP服务器并发送邮件
        try:
            smtp_obj = smtplib.SMTP_SSL(self.smtp_server, self.smtp_port)
            smtp_obj.login(self.sender, self.password)
            smtp_obj.sendmail(self.sender, [self.receiver], msg.as_string())
            logging.info('邮件发送成功')
            smtp_obj.quit()
        except smtplib.SMTPException as e:
            logging.error('邮件发送失败： %s' % e)


# 使用示例
if __name__ == "__main__":
    email_sender = EmailSender()
    email_sender.send_email()
