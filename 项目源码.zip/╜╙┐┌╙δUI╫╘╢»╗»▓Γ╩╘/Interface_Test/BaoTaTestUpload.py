import ftplib
import pandas as pd
import json
import ddt
import unittest

class FTPUploader:
    def __init__(self):
        self.server = "117.50.195.127"
        self.port = 21
        self.user = "francis"
        self.password =""

    def upload_file(self, local_file, remote_file):
        try:
            # 连接到 FTP 服务器
            ftp = ftplib.FTP()
            ftp.connect(self.server, self.port)
            ftp.login(self.user, self.password)

            # 打开本地文件
            with open(local_file, 'rb') as file:
                # 使用 STOR 命令上传文件
                ftp.storbinary(f'STOR {remote_file}', file)

            # 关闭 FTP 连接
            ftp.quit()
            print("文件上传成功！")
        except ftplib.all_errors as e:
            print(f"文件上传失败: {e}")

def read_excel(file, **kwargs):
    data_dict = []
    try:
        data = pd.read_excel(file, **kwargs)
        data_dict = data.to_dict('records')
    finally:
        return data_dict

Testdata = read_excel(r'data/宝塔上传文件.xlsx', sheet_name='端口测试用例')

@ddt.ddt
class TestUpload(unittest.TestCase):
    def setUp(self) -> None :
        self.ftp = FTPUploader()
        print("测试用例开始执行")

    @ddt.data(*Testdata)
    def test_upload(self, testdata):
        print(f"Running test: {testdata}")
        self._testMethodDoc = testdata["用例描述"]
        local_file = testdata["本地文件路径"]
        remote_file = testdata["远程文件名"]
        self.ftp.upload_file(local_file, remote_file)

    def tearDown(self):
        print("测试用例执行结束")