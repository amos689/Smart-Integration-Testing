import unittest
import urllib.parse
import requests
import ddt
import json
import pandas as pd
import time
import hashlib
import sys
import os
import json
import urllib.request
import ssl
import http.cookiejar

'''
    新增数据库
'''
class bt_api:
    def __init__(self, bt_panel=None, bt_key=None):
        self.__BT_KEY = bt_key or ''
        self.__BT_PANEL = bt_panel or 'http://117.50.195.127:10747'

    def __get_md5(self, s):
        m = hashlib.md5()
        m.update(s.encode('utf-8'))
        return m.hexdigest()

    def __get_key_data(self):
        now_time = int(time.time())
        p_data = {
            'request_token': self.__get_md5(str(now_time) + '' + self.__get_md5(self.__BT_KEY)),
            'request_time': now_time
        }
        return p_data

    def __http_post(self, url, p_data, timeout=1800):
        headers = {
            "accept": "application/json, text/plain, */*",
            "content-type": "application/x-www-form-urlencoded"
        }
        data = urllib.parse.urlencode(p_data).encode('utf-8')
        req = urllib.request.Request(url, data, headers=headers)
        response = urllib.request.urlopen(req, timeout=timeout)
        result = response.read()
        if isinstance(result, bytes):
            result = result.decode('utf-8')
        return result, response.getcode()

    def api_request(self, url, data):
        p_data = self.__get_key_data()
        p_data.update(data)
        result, status_code = self.__http_post(url, p_data)
        return json.loads(result), status_code

    def get_full_url(self, endpoint):
        return urllib.parse.urljoin(self.__BT_PANEL, endpoint)

def read_excel(file, **kwargs):
    data_dict = []
    try:
        data = pd.read_excel(file, keep_default_na=False, **kwargs)
        # 检查请求参数是否为空，为空则设置为空字典
        for index, row in data.iterrows():
            if not row['请求参数'] or pd.isna(row['请求参数']):
                data.at[index, '请求参数'] = '{}'
        data_dict = data.to_dict('records')
    finally:
        return data_dict

# 读取 Excel 文件中的测试数据
Testdata = read_excel(r'data/宝塔创建FTP用户.xlsx', sheet_name='接口测试用例')

@ddt.ddt
class TestFTPAPI(unittest.TestCase):
    def setUp(self) -> None:
        self.api = bt_api()
        print("测试用例执行前操作")

    @ddt.data(*Testdata)
    def test_Api(self, testdata):
        print(f"Running test: {testdata}")
        self._testMethodDoc = testdata["用例描述"]
        url = self.api.get_full_url(testdata["接口地址"])
        data = json.loads(testdata["请求参数"])
        response, status_code = self.api.api_request(url, data)
        print(type(response))
        print(response)
        # 独立判断状态码
        print(status_code)
        self.assertEqual(status_code, 200, f"Expected status code 200, but got {status_code}")

    def tearDown(self) -> None:
        print("测试用例执行后操作")

if __name__ == '__main__':
    unittest.main()
