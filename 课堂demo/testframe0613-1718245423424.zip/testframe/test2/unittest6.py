import unittest
# 整个模块开始前执行
def setUpModule():
    print("模块级别开始test module start")
# 整个模块结束时执行
def tearDownModule():
    print("模块级别结束test module end")

class MyTest(unittest.TestCase):

    # 测试用例类开始前执行
    @classmethod
    def setUpClass(cls) :
        print("类级别开始 test class start" )

    # 测试用例类结束时执行
    @classmethod
    def tearDownClass(cls) :
        print("类级别结束 test class end")

    # 测试用例开始前执行(以一条测试用例为单位)
    def setUp(self) -> None:
        print("用例级别开始 test case start")

    # 测试用例结束时执行(以一条测试用例为单位)
    def tearDown(self) -> None:
        print("用例级别结束 test case end")

    def test_case1(self):
        print("用例 test case1")

    def test_case2(self):
        print("用例 test case2")

if __name__ == '__main__':
    unittest.main()