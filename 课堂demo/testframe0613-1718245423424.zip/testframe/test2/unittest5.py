# 1. 导入unittest
import unittest
from ut_test1 import Test1
from ut_test2 import Test2

if __name__ == '__main__':
    suite = unittest.TestSuite()  # 实例化TestSuite
    suite.addTests([Test1("test_add_02"), Test1("test_add_01"), Test2("test_add_03"), Test2("test_add_04")])  # 添加测试用例
    runner = unittest.TextTestRunner()  # 实例化TextTestRunner
    runner.run(suite)  # 传入suite并执行测试用例