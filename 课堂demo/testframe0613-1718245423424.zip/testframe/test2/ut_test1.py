# 1. 导入unittest
import unittest

# 2. 创建类继承unittest.TestCase
class Test1(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        super().setUpClass()
        print("Test1测试前的操作")

    @classmethod
    def tearDownClass(cls) -> None:
        super().tearDownClass()
        print("Test1测试后的操作")

    # 3. 创建测试用例方法, 方法要以test开头
    # 执行顺序是根据case序号来的, 并非代码的顺序

    def test_add_01(self):
        print(3+2)

    def test_add_02(self):
        print(10+5)