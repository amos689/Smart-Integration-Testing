from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

driver = webdriver.Chrome()
# 使用隐式等待
driver.implicitly_wait(time_to_wait=30)
driver.get('https://www.baidu.com')

driver.maximize_window()
# 获取当前窗口的句柄
print("当前窗口的句柄")
print(driver.current_window_handle)

# xpath定位百度输入框
element = driver.find_element(By.XPATH,"//input[@id='kw']")
element.send_keys('selenium')

search = driver.find_element(By.ID,"su")
search.click()

# 使用显式等待
# 1、设置一个计时器
wait = WebDriverWait(driver, timeout=10, poll_frequency=0.5)
# 2、设置一个等待条件
# 元素可以被点击，返回一个element
locator = (By.XPATH, '//div[@mu="https://b2b.baidu.com/ss?q=selenium"]/div/h3/a')
element = wait.until(EC.visibility_of_element_located(locator=locator))
element.click()

# 获取当前浏览器所有窗口的句柄
handles=driver.window_handles
print("当前所有窗口的句柄")
print(handles)

# 切换句柄
# -1 代表最后一个打开的窗口
#driver.switch_to.window(handles[-1])
driver.switch_to.window(handles[0])

#locator = (By.XPATH, '//a[@title="端午将至 粽子飘香"]')
locator = (By.XPATH, '//div[@mu="http://www.seleniumhq.org/"]/div/h3/a')
element2 = wait.until(EC.visibility_of_element_located(locator=locator))
element2.click()