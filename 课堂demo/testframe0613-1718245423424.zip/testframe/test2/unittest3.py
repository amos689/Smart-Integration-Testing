import unittest

class Test(unittest.TestCase):
    def setUp(self) -> None:  # 调用setUp
        super().setUp()
        print("测试用例执行前操作")

    def test_add_01(self):
        print("test_add_01")

    def test_add_02(self):
        print("test_add_02")

    def tearDown(self) -> None:  # 调用tearDown
        super().tearDown()
        print("测试用例执行后操作")