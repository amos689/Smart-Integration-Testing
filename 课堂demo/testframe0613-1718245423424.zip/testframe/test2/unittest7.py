import unittest
class TestCaseDemo(unittest.TestCase):

    @unittest.skip('直接跳过')
    def testassertdemo(self):
        self.assertNotEqual(1, 1)

    def testassertdemo_1(self):
        self.assertListEqual([1, 2], [1, 2])

    def testassertdemo_2(self):
        self.assertNotRegex("1", "122")  # 正则是否匹配

if __name__ == '__main__':
    unittest.main()