import pandas as pd

def read_excel(file, **kwargs):
    data_dict = []
    try:
        data = pd.read_excel(file, **kwargs)
        data_dict = data.to_dict('records')
    finally:
        return data_dict

sheet2 = read_excel(r'./data/测试数据1.xlsx', sheet_name='账号')
print(sheet2[0]['访问地址'])
