from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import pandas as pd
import time

def read_excel(file, **kwargs):
    data_dict = []
    try:
        data = pd.read_excel(file, **kwargs)
        data_dict = data.to_dict('records')
    finally:
        return data_dict

sheet2 = read_excel(r'./data/测试数据1.xlsx', sheet_name='账号')
print(sheet2)

driver = webdriver.Chrome()
# 使用隐式等待
driver.implicitly_wait(time_to_wait=15)
driver.get(sheet2[1]['访问地址'])

driver.maximize_window()

# xpath定位用户名和密码框
username = driver.find_element(By.XPATH,"//input[@id='username']")
password = driver.find_element(By.XPATH,"//input[@id='password']")
username.send_keys(sheet2[1]['账号'])
password.send_keys(sheet2[1]['密码'])

form = driver.find_element(By.XPATH,"//form")
form.submit()

# 1、先找到鼠标要操作的元素
div_element = driver.find_element(By.XPATH,'//p[text()="双链生鲜供应链平台"]/..')
print(div_element.text)
print("***************test0*******************")
# 鼠标移动到点击区域
# 2、初始化ActionChains类
action = ActionChains(driver)
# 3、将鼠标操作添加到actions列表中
action.move_to_element(div_element)
action.click(div_element)
# 4、调用perform()来执行
action.perform()

print("***************test1*******************")
'''
elements=driver.find_elements(By.XPATH,'//div[@class="icon-item-box"]')
for i,ele in enumerate(elements):#a[@id="title-content"]
    print(i)
    print(ele.text)
'''

time.sleep(1)
elements2 = driver.find_elements(By.XPATH, '//div[@class="ant-layout-sider-children"]')
for i, ele in enumerate(elements2):
    print(i)
    print(ele.text)

print("***************test2*******************")
elements3=driver.find_elements(By.XPATH,'//div[@class="ant-spin-container"]/div/div/div/div/div/a')
for i,ele in enumerate(elements3):
    print(i)
    if(i==0):
        ele.click()

time.sleep(1)

print("***************test3*******************")
name_element = driver.find_element(By.XPATH,'//input[@id="name"]')
name_element.send_keys("测试名称1")

time.sleep(1)

print("***************test4*******************")
type_element = driver.find_element(By.XPATH,'//input[@class="ant-input"]')
type_element.send_keys("创建订单(CREATE_ORDER)")

btn_element = driver.find_element(By.XPATH,'//span[text()="下一步"]/..')
print(btn_element.text)
btn_element.click()

time.sleep(2)