import unittest
import requests
import ddt
import json
import pandas as pd

def read_excel(file, **kwargs):
    data_dict = []
    try:
        data = pd.read_excel(file, **kwargs)
        data_dict = data.to_dict('records')
    finally:
        return data_dict

# 测试数据,可以以列表中嵌套字典的形式,一个字典就是一个入参
Testdata = read_excel(r'./data/接口测试数据.xlsx', sheet_name='接口测试用例')

# 测试类前面需要加上@ddt.ddt
@ddt.ddt
class Test3(unittest.TestCase):
    def setUp(self) -> None:  # 调用setUp
        super().setUp()
        print("测试用例执行前操作")

    # 测试方法前面需要加上@ddt.dada()括号里面填入测试数据
    @ddt.data(*Testdata)
    def test_Api(self,testdata):       # testdata代表传入进来的每一条参数
        print(testdata["用例名称"])
        self._testMethodDoc=testdata["用例描述"]
        url = testdata["接口地址"]
        data1 = testdata["请求参数"]
        print(type(data1))
        data =json.loads(data1)
        print(type(data))
        response = requests.post(url=url, data=data)
        print(response.json())
        # self.assertRegex(testdata["预期内容2"], response.text)  # 正则是否匹配
        self.assertIn(testdata["预期内容2"], response.text)

    def tearDown(self) -> None:  # 调用tearDown
        super().tearDown()
        print("测试用例执行后操作")