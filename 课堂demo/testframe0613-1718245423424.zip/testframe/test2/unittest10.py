import requests
url = 'http://v.juhe.cn/laohuangli/d'
data = {
    "key":"1544c7a8867d5ac28bb16e9e84137966",
    "date":'2024-06-04'
}

res = requests.post(url=url,data=data)
print(res.json())
