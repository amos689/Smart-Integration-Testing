from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

driver = webdriver.Chrome()
# 使用隐式等待
driver.implicitly_wait(time_to_wait=10)
driver.get('https://www.baidu.com')

driver.maximize_window()
# xpath定位百度输入框
element = driver.find_element(By.XPATH,"//input[@id='kw']")
# 打印对象
print(element.size)
print(element.text)
print(element.get_attribute("name"))
print(element.get_attribute("class"))

print("查找span")
elements=driver.find_elements(By.XPATH,'//span[@class="title-content-title"]')
#/ul[@class="s-news-rank-content"]/li[@class="news-meta-item clearfix"]'
for i,ele in enumerate(elements):#a[@id="title-content"]
    print(i)
    print(ele.text)

element.send_keys('selenium')

search = driver.find_element(By.ID,"su")
search.click()


