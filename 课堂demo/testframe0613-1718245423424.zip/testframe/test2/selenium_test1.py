from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

driver = webdriver.Chrome()
# 使用隐式等待
driver.implicitly_wait(time_to_wait=10)
driver.get('https://www.baidu.com')

driver.maximize_window()

# xpath定位百度输入框
element = driver.find_element(By.XPATH,"//input[@id='kw']")
element.send_keys('俄乌冲突')

#search = driver.find_element(By.ID,"su")
search = driver.find_element(By.XPATH,"//input[@value='百度一下']")
search.click()

elements=driver.find_elements(By.XPATH,'//div[@id="s-hotsearch-wrapper"]')
#/ul[@class="s-news-rank-content"]/li[@class="news-meta-item clearfix"]'
for i,ele in enumerate(elements):#a[@id="title-content"]
    print(i)
    print(ele.text)
# 打印对象的类型
print(type(element))
