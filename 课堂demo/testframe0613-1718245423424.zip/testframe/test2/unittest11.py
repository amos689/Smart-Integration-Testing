import unittest
import ddt
import requests

# 测试数据,可以以列表中嵌套字典的形式,一个字典就是一个入参
Testdata = [
    {"date":'2021-06-06'},
    {"date":'2022-06-06'}
]
# 测试类前面需要加上@ddt.ddt
@ddt.ddt
class TestDttDemo(unittest.TestCase):
    def setUp(self) -> None:
        print('开始')

    def tearDown(self) -> None:
        print('结束')
# 测试方法前面需要加上@ddt.dada()括号里面填入测试数据
    @ddt.data(*Testdata)
    def test_Api(self,testdata):       # testdata代表传入进来的每一条参数
        url = 'http://api.juheapi.com/japi/toh'
        data = {
            "key":"1544c7a8867d5ac28bb16e9e84137966",
            "date":testdata["date"]
        }
        response = requests.post(url=url,data=data)
        print(response.json())

if __name__ == '__main__':
    unittest.main()