from BeautifulReport import BeautifulReport  # 需要导入BeautifulReport
import unittest
from ut_test3 import Test3

def suite():
    # 创建一个测试套件
    suite = unittest.TestSuite()
    # 将测试用例加载到测试套件中
    loader = unittest.TestLoader() # 创建一个用例加载对象
    suite.addTest(loader.loadTestsFromTestCase(Test3))
    return suite

if __name__ == '__main__':
    br = BeautifulReport(suite())
    br.report(filename='testdemoreport.html',description='测试报告',report_dir='.')