# 1. 导入unittest
import unittest

# 2. 创建类继承unittest.TestCase
class Test2(unittest.TestCase):

    @classmethod
    def setUpClass(cls) -> None:
        super().setUpClass()
        print("Test2测试前的操作")

    @classmethod
    def tearDownClass(cls) -> None:
        super().tearDownClass()
        print("Test2测试后的操作")

    def test_add_03(self):
        print(20)

    def test_add_04(self):
        print(40)