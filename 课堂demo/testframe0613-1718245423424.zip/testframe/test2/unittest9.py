import unittest
class TestCaseDemo(unittest.TestCase):

    @unittest.skipIf(3>2,'前面条件为真时，跳过此用例')
    def testassertdemo(self):
        self.assertNotEqual(1, 1)

    @unittest.skipUnless(3 > 2, '前面条件为真时，需要执行此用例')
    def testassertdemo(self):
        self.assertNotEqual(1, 1)
        
    @unittest.expectedFailure
    def testassertdemo(self):
        self.assertNotEqual(1, 2)

    def testassertdemo_1(self):
        self.assertListEqual([1, 2], [1, 2])

    def testassertdemo_2(self):
        self.assertNotRegex("1", "122")  # 正则是否匹配

if __name__ == '__main__':
    unittest.main()
