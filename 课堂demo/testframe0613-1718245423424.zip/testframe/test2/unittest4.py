import unittest

class Test(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        super().setUpClass()
        print("测试类前的操作")

    @classmethod
    def tearDownClass(cls) -> None:
        super().tearDownClass()
        print("测试类后的操作")

    def test_add_01(self):
        print(3+2)

    def test_add_02(self):
        print(10+5)