#!/usr/bin/python
# coding=utf-8
import requests
import unittest

class TestApi(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.query_url = 'http://127.0.0.1:8090/system/employee/queryOne'
        cls.userid = '1'
        cls.username = '刘世昌'
    # 测试用例类结束时执行
    @classmethod
    def tearDownClass(cls) :
        print("success")

    def test_info(self):
        data = {
            'id': self.userid,
            'name': self.username
        }

        response = requests.post(self.query_url, data=data)
        result = response.json()
        print(result)
        self.assertIn('hello',response.text,'测试失败！')
