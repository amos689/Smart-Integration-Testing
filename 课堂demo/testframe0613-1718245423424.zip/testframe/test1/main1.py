from test_api import TestApi

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    tl=TestApi()
    tl.setUpClass()
    tl.test_info()
    tl.tearDownClass()
