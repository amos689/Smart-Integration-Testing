#!/usr/bin/python
# coding=utf-8
import requests
import unittest

class TestLogin(unittest.TestCase):
 
    @classmethod
    def setUpClass(cls):
        cls.login_url = 'http://127.0.0.1:9999/login'
        cls.info_url = 'http://127.0.0.1:9999/findTeacherInfo'
        cls.username = '2004'
        cls.password = '123456'
 
    def test_login(self):
        data = {
            'xuehao': self.username,
            'password': self.password
        }
 
        response = requests.post(self.login_url, data=data).text
        print(str(response))
        assert '选择课程' in str(response),'接口异常'
 
    def test_info(self):
        data = {'t_id': 1 }
        response = requests.get(self.info_url, json=data).text
        print(str(response))
        assert '刘世昌' in str(response),'接口异常'
 